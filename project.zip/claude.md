Issues. Solve in SECTIONS.

1. Media tab: remove the outs & strikeouts they are redundant section
